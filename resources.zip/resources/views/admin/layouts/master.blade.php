<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="{{asset('assets/img/ficon.png')}}" type="image/png">
    <meta name="Keywords" content=""/>
    @include('admin.layouts.head')

    <style type="text/css" media="print">
        @media print {
            .app-content, .content {
                margin-right: 0 !important;
            }

            body {
                -webkit-print-color-adjust: exact;
                -moz-print-color-adjust: exact;
                print-color-adjust: exact;
                -o-print-color-adjust: exact;
            }

            .no-print {
                display: none;
            }

            .printy {
                display: block !important;
            }
        }
    </style>
    <style>
        @font-face {
            font-family: 'Almarai';
            src: url("{{asset('fonts/SegoeUI.ttf')}}");
        }
        label {
            font-size: 14px !important;
        }

        table {
            font-size: 14px !important;
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: 'Almarai' !important;
        }

        .dropdown-menu.dropdown-menu-right.show {
            width: 200px !important;
        }

        body, html {
            font-family: 'Almarai' !important;
            font-size: 14px !important;
        }

        .navigation.navigation-main {
            padding-bottom: 200px !important;
        }

        .btn-md, .badge {
            font-family: 'Almarai' !important;
            font-size: 14px !important;
        }

        .btn.dropdown-toggle.bs-placeholder, .btn.dropdown-toggle {
            height: 40px !important;
        }
        .select2-selection__rendered {
            line-height: 40px !important; border-radius: 0!important;
        }
        .select2-container .select2-selection--single {
            height: 40px !important;border-radius: 0!important;
        }
        .select2-selection__arrow {
            height: 40px !important;border-radius: 0!important;
        }
        .select2-search__field{
            height: 40px!important;
            line-height: 40px!important;
            outline: 0!important;
        }
        .dropdown-menu.show{
            right: 0!important;
            left: auto!important;
        }
        .side-menu__icon {
            font-size: 14px !important;
        }
        ::-webkit-scrollbar {
            width: 10px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: #fff!important;
            border-radius: 5px;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background: #444!important;
            border-radius: 5px;
        }

        /* Handle on hover */
        ::-webkit-scrollbar-thumb:hover {
            background: #444!important;
        }
        table.display.w-100.text-nowrap.table-bordered.dataTable.dtr-inline {
            direction: rtl;
            text-align:center;
        }
        body{
            direction: rtl; 
        }
        table#example1 tr td {
            padding: 5px !important;
            font-size:14px !important;
        }
        .btn-secondary {
            background-color: #0d6efd !important;
            border-color: #0d6efd; 
            border: 1px solid; 
        }
        .dt-buttons.btn-group.flex-wrap {
            margin-right: 3%;
            position: relative;
        }
        .input-group.wide-tip {
            border: 2px solid #ecf0fa;
            padding: 1%;
            border-radius: 10px;
            background: #ecf0fa;
        }
    </style>
</head> 
<body class="main-body app sidebar-mini">
@include('admin.layouts.main-sidebar')
<!-- main-content -->
<div class="main-content app-content">
@include('admin.layouts.main-header')
<!-- container -->
    <div class="container-fluid">
        @yield('page-header')
        @yield('content')
    </div>
</div>
@include('admin.layouts.footer')
@include('admin.layouts.footer-scripts')
</body>
</html>
