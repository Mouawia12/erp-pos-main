<div class="main-footer ht-40" id="main-footer">
    <div class="container-fluid pd-t-0-f ht-100p" dir="rtl">
        <span> 
            جميع الحقوق محفوظة. 
            {{date('Y')}}
        </span>
    </div>
</div>
