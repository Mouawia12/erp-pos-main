<?php

namespace App\Http\Controllers\Api;
 
use App\Models\User; 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;  
use Symfony\Component\HttpFoundation\Response;
use Tymon\JWTAuth\Facades\JWTAuth; 
use Illuminate\Support\Facades\DB;
use Validator;

class ApiController extends Controller
{
  
  
}
